# NPZ (pair_records.npz) references 鈥?R3.1

Generated (UTC): 2026-09-18T05:35:18+00:00

The per-window `pair_records.npz` files are too large for the portable archive.
They are referenced here by absolute path + SHA256.

| Window | Label | Filename | Size (bytes) | SHA256 | Source path |
|--------|-------|----------|--------------|--------|-------------|
| 5000 | 5K snapshot | pair_records.npz | 6019286717 | `80eb2a9ad4cc514f0d719ba0345d44b1d761f9cb0e403c7eb7b12afbb509f4c0` | `/mnt/storage_pool/liaoyuanjun/r3_1_full/5000/pair_records.npz` |
| 15000 | 15K snapshot | pair_records.npz | 4514811810 | `edb53fac2faa939c8bd9502265f158aaede5d5a2ded3ce8fe39bfab43b8e8cb2` | `/mnt/storage_pool/liaoyuanjun/r3_1_full/15000/pair_records.npz` |

## Verification (on source host):

```bash
sha256sum /mnt/storage_pool/liaoyuanjun/r3_1_full/5000/pair_records.npz
sha256sum /mnt/storage_pool/liaoyuanjun/r3_1_full/15000/pair_records.npz
```
