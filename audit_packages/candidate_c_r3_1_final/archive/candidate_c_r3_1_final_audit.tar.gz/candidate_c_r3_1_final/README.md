# Candidate C 鈥?R3.1 Certificate Repair Audit Package

**Generated (UTC):** 2026-09-18T05:21:05+00:00
**Total violations:** 0
**Windows:** 5K snapshot, 15K snapshot, 30K mature snapshot (30 cameras each)

## Key fix (R3.1-B)
Replaced `||conic_i||` (conic norm proxy) with `||c_i||` (true SH-evaluated
color norm) in all appearance-factor certificate bounds.  This was the root
cause of the 7,494 violations in R3.

## Package layout
```
candidate_c_r3_1_final/
鈹溾攢鈹€ README.md
鈹溾攢鈹€ SHA256SUMS.txt
鈹溾攢鈹€ manifest.csv
鈹溾攢鈹€ NPZ_REFERENCES.md          (all 3 NPZ files referenced)
鈹溾攢鈹€ analysis/                   (aggregated verification + decision)
鈹溾攢鈹€ archive/                    (portable tar.gz)
鈹溾攢鈹€ checkpoints/                (checkpoint manifest with symlink semantics)
鈹溾攢鈹€ docs/                       (certificate derivation, decision protocol, etc.)
鈹溾攢鈹€ raw/{5000,15000,30000}/   (per-snapshot certificate JSONs + logs)
鈹斺攢鈹€ source/                     (R3.1 experiment scripts)
```

## Verification
```bash
sha256sum -c SHA256SUMS.txt   # must 100% PASS
```

## Archive
- File: `archive/candidate_c_r3_1_final_audit.tar.gz`
- SHA256: `a6a2ece76cd0948b4774948b90ac84a3a1af9a075eda1539c1b35253362cc292`
