# Decision Protocol 鈥?CR1鈥揅R4 (from r3_decision.py source code)

**Source of truth:** `experiments/r3/r3_decision.py` (frozen commit `32ab80e`)

---

## CR1 鈥?Correctness

**Check:** Zero aggregate certificate violations across ALL families and ALL
iterations.

**Families checked (8):**
- Geometry primary: `mean2d`, `conic`, `mean2d_sigmamin`, `conic_sigmamin`
- Appearance secondary: `color_coarse`, `color_tight`, `opacity`, `opacity_tight`

**Data source:** `certificate_correctness.json` 鈫?`correctness[iter][family].violation_count`

**Pass condition:** `violation_count == 0` for every available family in every iteration.

---

## CR2 鈥?JOINT Weighted-Work Removal

**Check:** JOINT weighted derivative-work removal fraction at 5% budget.

**Data source:** `tile_gaussian_certificate.json` 鈫?`joint_skip[iter][eps_key]`

**Metrics extracted:**
- `JOINT_SKIP_WEIGHTED_WORK_FRACTION` 鈥?primary gate
- `JOINT_SKIP_PAIR_FRACTION` 鈥?secondary
- `LOSS_CONDITIONED_NONZERO_SUPPORT_CULLING` 鈥?Candidate C novelty signal
  (excludes exact-zero prior-art support culling)

**Thresholds:**
- `>= 30%` 鈫?CR2 PASS (C_KEEP eligible)
- `10% 鈥?30%` 鈫?CR2 MODERATE (C_MODIFY eligible)
- `< 10%` 鈫?CR2 FAIL (C_DROP)

**Budget levels reported:** 0.5%, 1%, 2%, 5%

---

## CR3 鈥?Signal Coverage

**Check:** Signal persists across at least 3 canonical windows.

**Data source:** Union of iteration keys from `correctness` and `joint_skip`.

**Pass condition:** `len(windows_seen) >= 3`

---

## CR4 鈥?SPD Certifiability

**Check:** SPD (Symmetric Positive Definite) disabled fraction is small enough
that the certificate covers the vast majority of Gaussians.

**Data source:** `certificate_disabled.json` 鈫?`disabled[iter].spd_disabled_count`

**Pass condition:** `disabled_fraction < 10%`

---

## Final Decision Logic

```
if CR1 pass AND CR2 pass (>=30%) AND CR3 pass AND CR4 pass:
    鈫?C_KEEP
elif CR1 pass AND CR2 moderate (10-30%) AND CR3 pass:
    鈫?C_MODIFY
else:
    鈫?C_DROP
```

**Key rule:** CR1 failure (any violation) 鈫?automatic C_DROP, regardless of
opportunity numbers. Correctness is a hard gate.

---

## Critical Distinction (Red-Team Req 4)

- **EXACT_ZERO_SUPPORT_CULLING** = alpha < 1/255 pairs
  鈫?Prior art (Speedy-Splat, AccuTile). NOT counted as Candidate C novelty.
- **LOSS_CONDITIONED_NONZERO_SUPPORT_CULLING** = pairs inside nonzero support
  that are skippable due to loss-conditioned derivative bounds.
  鈫?THIS is Candidate C's primary novelty signal.

---

## Input Requirements

`r3_decision.py --input <DIR>` expects `<DIR>` to contain these 6 files:
1. `certificate_correctness.json`
2. `certificate_tightness.json`
3. `complexity_accounting.json`
4. `exact_zero_statistics.json`
5. `certificate_disabled.json`
6. `tile_gaussian_certificate.json`

The script writes `final_decision.json` into `<DIR>`.

